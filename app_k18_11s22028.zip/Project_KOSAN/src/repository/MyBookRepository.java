package repository;

import entity.MyBook;

import java.util.ArrayList;

public interface MyBookRepository {
    public ArrayList<MyBook> getAllK(String keywords);
    public ArrayList<MyBook> getAll(String keywords, String cbxStat);
    public MyBook getByISBN(Integer isbn);
    public boolean add(MyBook myBook);
    public boolean remove(Integer isbn);
    public boolean change(Integer isbn, MyBook mybook);
    public boolean updateReading(Integer isbn, Integer currentPages);
    public boolean Archive(int isbn, boolean status);

    public ArrayList<MyBook> getAll();
    
}
