package repository;

import entity.MyBook;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import utils.DB;

public class MyBookRepositoryImpl implements MyBookRepository {
    
    private final DB db;
    public MyBookRepositoryImpl(){
        db = new DB();
    }
    
    public ArrayList<MyBook> data = new ArrayList<MyBook>();

    @Override
    public ArrayList<MyBook> getAllK(String keywords) {
        ArrayList<MyBook> model = new ArrayList<>();
        String query = "SELECT * FROM mybook";
        ResultSet resultSet = db.get(query, null);
        if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    Integer isbn = resultSet.getInt("isbn");
                    String judul = resultSet.getString("judul");
                    String penulis = resultSet.getString("penulis");
                    String penerbit = resultSet.getString("penerbit");
                    Integer tahun_terbit = resultSet.getInt("tahun_terbit");
                    Integer halaman = resultSet.getInt("jumlah_halaman");
                    int last_page = resultSet.getInt("last_page");
                    boolean status = resultSet.getBoolean("status");
                    
                    MyBook mybook = new MyBook(isbn, judul, penulis, penerbit, tahun_terbit,halaman, last_page, status);
                    model.add(mybook);
                }
            } catch (SQLException ex) {
            }
        }
        return model;
    }
    
    @Override
    public ArrayList<MyBook> getAll(String keywords, String cbxStat) {
        ArrayList<MyBook> model = new ArrayList<>();
        String query = "SELECT * FROM mybook";
        ResultSet resultSet = db.get(query, null);
        if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    Integer isbn = resultSet.getInt("isbn");
                    String judul = resultSet.getString("judul");
                    String penulis = resultSet.getString("penulis");
                    String penerbit = resultSet.getString("penerbit");
                    Integer tahun_terbit = resultSet.getInt("tahun_terbit");
                    Integer halaman = resultSet.getInt("jumlah_halaman");
                    int last_page = resultSet.getInt("last_page");
                    boolean status = resultSet.getBoolean("status");
                    
                    MyBook mybook = new MyBook(isbn, judul, penulis, penerbit, tahun_terbit,halaman,last_page, status);
                    model.add(mybook);
                }
            } catch (SQLException ex) {
            }
        }
        return model;
    }
    

    @Override
    public MyBook getByISBN(Integer isbn) {
        MyBook mybook = null;
        String query = "SELECT * FROM mybook WHERE isbn = ?";
        String[] values = new String[]{String.valueOf(isbn)};
        ResultSet resultSet = db.get(query, values);
        if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    mybook = new MyBook(resultSet.getInt("isbn"), resultSet.getString("judul"), resultSet.getString("penulis"),
                    resultSet.getString("penerbit"),resultSet.getInt("tahun_terbit"),resultSet.getInt("jumlah_halaman"),
                    resultSet.getInt("last_page"),resultSet.getBoolean("status"));
                    break;
                }
            } catch (SQLException ex) {
// Terjadi kesalahan pada JDBC
            }
        }
        return mybook;
    }

    @Override
    public boolean add(MyBook myBook) {
        String query = "INSERT INTO mybook (isbn, judul, penulis, penerbit, "
                + "tahun_terbit, jumlah_halaman) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        String[] values = new String[]{String.valueOf(myBook.getIsbn()),myBook.getTitle(),
            myBook.getAuthor(),myBook.getPublisher(),String.valueOf(myBook.getYear()),
            String.valueOf(myBook.getTotalPages()),String.valueOf(myBook.getCurrentPages())};
            return db.update(query, values);
    }

    @Override
    public boolean remove(Integer isbn) {
        String query = "DELETE FROM mybook WHERE isbn = ?";
        String[] values = new String[]{String.valueOf(isbn)};
        return db.update(query, values);
    }
    
    @Override
    public boolean change(Integer isbn, MyBook mybook) {
        String query = "UPDATE mybook SET judul = ?, penulis = ?, penerbit = ?, "
                + "tahun_terbit = ?, totalpages = ? WHERE isbn = ?";
            String[] values = new String[]{mybook.getTitle(), mybook.getAuthor(),
            mybook.getPublisher(), String.valueOf(mybook.getYear()), 
            String.valueOf(mybook.getTotalPages())};
            return db.update(query, values);
    }

    @Override
    public boolean updateReading(Integer isbn, Integer currentPages) {
        String query = "UPDATE mybook SET last_page = ? where isbn = ?";
        
        String values [] = new String []{String.valueOf(currentPages), String.valueOf(isbn)};
        return db.update(query, values);
    }
    
    @Override
    public boolean Archive(int isbn, boolean status) {
        String query = "UPDATE mybook SET status = ? where isbn = ?";
        
        String stat = "0";
        if (status) {
            stat = "1";
        }
        String values [] = new String []{String.valueOf(stat), String.valueOf(isbn)};
        
        return db.update(query, values);
    }


    @Override
    public ArrayList<MyBook> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
