package service;

import entity.MyBook;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import repository.MyBookRepository;
import java.util.ArrayList;
import java.util.EventObject;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import utils.ButtonEditor;



public class MyBookServiceImpl implements MyBookService {

    private MyBookRepository myBookRepository;
    private JTable tblTodo;
    
    
    public MyBookServiceImpl (MyBookRepository myBookRepository){
        this.myBookRepository = myBookRepository;
    }
    
    @Override
    public void setTableTodo(JTable tblTodo) {
        this.tblTodo = tblTodo;
    }
    
    @Override
    public void tableHandling() {
        
        try {
            JTable tblTodo = this.tblTodo;
            tblTodo.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(new JTextField()) {
                @Override
                public boolean isCellEditable(EventObject anEvent) {
                    return false;
                }
            });
            
                // Membuat JComboBox untuk memilih antara semester gasal dengan genap
                JComboBox<String> cbxStatus = new JComboBox<>();
                cbxStatus.addItem("Selesai");
                cbxStatus.addItem("Belum Selesai");

             

                // Membuat Button untuk kolom di JTable
                    // Membuat Button Editor untuk ditambahkan ke kolom JTabel
              
            
                tblTodo.getDefaultEditor(String.class).addCellEditorListener(new CellEditorListener() {
                    @Override
                    public void editingStopped(ChangeEvent e) {
                        
                        int row = tblTodo.getSelectedRow();
                        int column = tblTodo.getSelectedColumn();
                        String selectedValue = tblTodo.getValueAt(row, column).toString();
                        System.out.println("Cell di baris " + row + ", kolom " + column + " diubah menjadi: " + selectedValue);
                    }
                @Override
                public void editingCanceled(ChangeEvent e) {
                    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
                }
                
                    });
                    
                    
                      // Membuat Button untuk kolom di JTable
                     {
                }
                
                
        } catch (Error e) { 
        } catch (Exception e) {
            
        }
    }
    
        @Override
    public void loadData(String keywords) {
        JTable tblTodo = this.tblTodo;
        
        ArrayList<MyBook> model = myBookRepository.getAll();
        DefaultTableModel tableModel = new DefaultTableModel(null, new Object[]{"ISBN", "Judul", 
            "Penulis", "Penerbit", "Tahun Terbit", "Halaman", "Status"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        

        tblTodo.setModel(tableModel);
        tblTodo.setCellSelectionEnabled(false);
        tblTodo.setRowSelectionAllowed(true);
        tblTodo.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblTodo.setRowHeight(30);

        TableColumnModel columnModel = tblTodo.getColumnModel();

        TableColumn columnISBN = columnModel.getColumn(0);
        columnISBN.setPreferredWidth(150);

        TableColumn columnTitle = columnModel.getColumn(1);
        columnTitle.setPreferredWidth(150);

        TableColumn columnAuthor = columnModel.getColumn(2);
        columnAuthor.setPreferredWidth(150);
        
        TableColumn columnPublisher = columnModel.getColumn(3);
        columnPublisher.setPreferredWidth(150);
        
        TableColumn columnYear = columnModel.getColumn(4);
        columnYear.setPreferredWidth(150);
        
        TableColumn columnPages = columnModel.getColumn(5);
        columnPages.setPreferredWidth(150);
        
        TableColumn columnStatus = columnModel.getColumn(6);
        columnStatus.setPreferredWidth(160);
        
        
        
        if (!model.isEmpty()) {
        for (var i = 0; i < model.size(); i++) {
        var mybook = model.get(i);
        
                        if (!mybook.isArchived()){
                        if (keywords == null || (mybook.getTitle().contains(keywords))) {
                    tableModel.addRow(new Object[]{mybook.getIsbn(), mybook.getTitle(), mybook.getAuthor(), 
                        mybook.getPublisher(),mybook.getYear(),mybook.getCurrentPages() + " / " + mybook.getTotalPages(), "Belum Diarsipkan"
                    });
                        }
                        }
                
            }
        }
    }
    
    @Override
    public void loadLibData(String cbxStat) {
        JTable tblTodo = this.tblTodo;

        ArrayList<MyBook> model = myBookRepository.getAllK(cbxStat);
        DefaultTableModel tableModel = new DefaultTableModel(null, new Object[]{"ISBN", "Judul", "Penulis", "Penerbit", "Tahun Terbit", "Halaman"}) {
    @Override
    public boolean isCellEditable(int row, int column) {
                return true;
            }
        };
        
        if (!model.isEmpty()) {
    for (var i = 0; i < model.size(); i++) {
        var mybook = model.get(i);
        var status = mybook != null && mybook.isArchived();

        if (cbxStat == null ||(cbxStat.equals("Belum Diarsipkan") 
             && !mybook.isArchived()) ||
            (cbxStat.equals("Diarsipkan") && mybook.isArchived())) {
            if ((mybook != null)) {
                tableModel.addRow(new Object[]{mybook.getIsbn(), mybook.getTitle(), status, "Hapus"});
            }
        }

        tblTodo.setModel(tableModel);
        tblTodo.setCellSelectionEnabled(false);
        tblTodo.setRowSelectionAllowed(true);
        tblTodo.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblTodo.setRowHeight(30);

        TableColumnModel columnModel = tblTodo.getColumnModel();

        TableColumn columnISBN = columnModel.getColumn(0);
        columnISBN.setPreferredWidth(150);

        TableColumn columnTitle = columnModel.getColumn(1);
        columnTitle.setPreferredWidth(150);

        TableColumn columnAuthor = columnModel.getColumn(2);
        columnAuthor.setPreferredWidth(150);
        
        TableColumn columnPublisher = columnModel.getColumn(3);
        columnPublisher.setPreferredWidth(150);
        
        TableColumn columnYear = columnModel.getColumn(4);
        columnYear.setPreferredWidth(150);
        
        TableColumn columnPages = columnModel.getColumn(5);
        columnPages.setPreferredWidth(150);
        
        TableColumn columnStatus = columnModel.getColumn(6);
        columnStatus.setPreferredWidth(150);

    }
}
    }
    
    @Override
    public void loadSearch(String keywords) {
        JTable tblTodo = this.tblTodo;

        ArrayList<MyBook> model = myBookRepository.getAllK(keywords);
        DefaultTableModel tableModel = new DefaultTableModel(null, new Object[]{"ISBN", "Judul", 
            "Penulis", "Penerbit", "Tahun Terbit", "Halaman", "Status"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblTodo.setModel(tableModel);
        tblTodo.setCellSelectionEnabled(false);
        tblTodo.setRowSelectionAllowed(true);
        tblTodo.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblTodo.setRowHeight(30);

        TableColumnModel columnModel = tblTodo.getColumnModel();

        TableColumn columnISBN = columnModel.getColumn(0);
        columnISBN.setPreferredWidth(150);

        TableColumn columnTitle = columnModel.getColumn(1);
        columnTitle.setPreferredWidth(150);

        TableColumn columnAuthor = columnModel.getColumn(2);
        columnAuthor.setPreferredWidth(150);
        
        TableColumn columnPublisher = columnModel.getColumn(3);
        columnPublisher.setPreferredWidth(150);
        
        TableColumn columnYear = columnModel.getColumn(4);
        columnYear.setPreferredWidth(150);
        
        TableColumn columnPages = columnModel.getColumn(5);
        columnPages.setPreferredWidth(150);
        
        TableColumn columnStatus = columnModel.getColumn(6);
        columnStatus.setPreferredWidth(150);

        if (!model.isEmpty()) {
    for (var i = 0; i < model.size(); i++) {
        var mybook = model.get(i);
        var status = mybook != null && mybook.isArchived() ? "Belum Diarsipkan" : "Diarsipkan";
        
        if (keywords == null || (mybook != null && mybook.getTitle().contains(keywords))) {
                tableModel.addRow(new Object[]{mybook.getIsbn(), mybook.getTitle(), 
                    mybook.getAuthor(), mybook.getPublisher(), mybook.getYear(),
                       mybook.getCurrentPages() + " / " + mybook.getTotalPages(), 
                       status});
            }
    }
}
    }
    
    @Override
    public void showMyBookLib(String cbxStat) {
        loadLibData(cbxStat);
        tableHandling();
    }
    
     @Override
    public void showMyBook(String keywords) {
        loadData(keywords);
        tableHandling();
    }
    
     @Override
    public void showMyBookSearch(String keywords) {
        loadSearch(keywords);
        tableHandling();
    }

    @Override
    public boolean readingMyBook(Integer isbn) {
        MyBook membaca = null;
        boolean succes = false;
        return succes;
    }

    @Override
    public void addMyBook(Integer isbn, String title, String author, String publisher, Integer year, Integer totalPages) {
        MyBook mybook = new MyBook(isbn, title, author, publisher, year, totalPages);
        boolean success = myBookRepository.add(mybook);
        if (success) {
            System.out.println("SUKSES MENAMBAH MY BOOK : " + mybook.getTitle());
        } else {
            System.out.println("GAGAL MENAMBAH MY BOOK : " + mybook.getTitle() + ". Panjang karakter minimal 6.");
        }
    }

    @Override
    public void removeMyBook(Integer isbn) {
        boolean succes = myBookRepository.remove(isbn);
        System.out.println();
        if (succes) {
            System.out.println("SUKSES MENGHAPUS MY BOOK : " + isbn);
        } else {
            System.out.println("GAGAL MENGHAPUS MY BOOK : " + isbn);
        }
    }
    
    @Override
    public void changeMyBook(Integer number, String title, String author, String publisher, Integer year, Integer totalPages) {

        MyBook mybook = new MyBook(number, title, author, publisher, year, totalPages);
        boolean result = myBookRepository.change(number, mybook);
        System.out.println("Status: " + mybook.isArchived());
        if (result) {
            System.out.println("SUKSES MENGUBAH TODO : posisi ke-" + number + " menjadi " + mybook.getTitle());
        } else {
            if (mybook == null) {
                System.out.println("GAGAL MENGUBAH TODO : posisi ke-" + number + " menjadi " + mybook.getTitle() + ". Todo tidak tersedia.");
            }
        }
    }

    @Override
    public void updateReadingMyBook(Integer isbn, Integer currentPages) {
        MyBook myBook = new MyBook(isbn, currentPages);
        boolean succes = myBookRepository.updateReading(isbn, currentPages);
        if(succes){
            System.out.println("Sukses Membaca " + myBook.getCurrentPages() + " Halaman ");                
                  } else {
            System.out.println("Gagal Membaca" + myBook.getTitle()+ "Jumlah Halaman" + myBook.getTotalPages());
        }
        showMyBook("s");
    }
    
    @Override
    public void updateArchive(int isbn, boolean status) {
            boolean succes = myBookRepository.Archive(isbn, status);
        if(succes){
            System.out.println("Sukses Membaca "  + " Halaman ");                
                  } else {
            System.out.println("Gagal Membaca" + "Jumlah Halaman" );
        }
    }

    @Override
    public MyBook getMyBook(Integer isbn) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
