package service;

import entity.MyBook;
import javax.swing.JTable;

public interface MyBookService {

    public void setTableTodo(JTable tblTodo);

    public void tableHandling();

    public boolean readingMyBook(Integer isbn);

    public void loadData(String keywords);

    public void loadLibData(String cbxStat);

    public void loadSearch(String keywords);

    public void showMyBookLib(String cbxStat);

    public void showMyBook(String keywords);

    public void showMyBookSearch(String keywords);

    public void addMyBook(Integer isbn, String title, String author, String publisher, Integer year, Integer totalPages);

    public void removeMyBook(Integer isbn);

    public void changeMyBook(Integer isbn, String title, String author, String publisher, Integer year, Integer totalPages);

    public void updateReadingMyBook(Integer isbn, Integer currentPages);
    
    public void updateArchive(int isbn, boolean status);

    public MyBook getMyBook(Integer isbn);

}
