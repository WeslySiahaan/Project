/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui.pages;

/**
 *
 * @author TUF GAMING 15
 */
public class kontroller {
    public static MyBookPages myBookPages = new MyBookPages();
    public static ArchivePages archivePages = new ArchivePages();
    public static AboutPages aboutPages = new AboutPages();
    public static HomePages homePages = new HomePages();
    
}
