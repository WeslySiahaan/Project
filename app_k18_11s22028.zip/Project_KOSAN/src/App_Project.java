import repository.MyBookRepository;
import repository.MyBookRepositoryImpl;
import service.MyBookService;
import service.MyBookServiceImpl;
import ui.Tampilan;

public class App_Project {

    public static void main(String[] args) {
        MyBookRepository myBookRepository = new MyBookRepositoryImpl();
        MyBookService myBookService = new MyBookServiceImpl(myBookRepository);
        Tampilan tampilan = new Tampilan();
        
        tampilan.setMyBookService(myBookService);
        tampilan.setVisible(true);
    }
}

