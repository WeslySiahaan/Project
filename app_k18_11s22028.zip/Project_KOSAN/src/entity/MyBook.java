package entity;

public class MyBook {
    Integer isbn;
    String title;
    String author;
    String publisher;
    Integer year;
    Integer totalPages;
    Integer currentPages = 0;
    boolean isArchived = false;

    public MyBook(int isbn, String title, String author, String publisher, Integer year, Integer totalPages) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.totalPages = totalPages;
        this.currentPages = 0;
        this.isArchived = false;
    } 
    
    public MyBook(Integer isbn, String title, String author, String publisher, Integer year, Integer totalPages, boolean isArchived) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.totalPages = totalPages;
        this.currentPages = 0;
        this.isArchived = false;
    }
      
    public MyBook(Integer isbn, String title, String author, String publisher, Integer year, Integer totalPages, Integer currentPages, boolean isArchived) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.year = year;
        this.totalPages = totalPages;
        this.currentPages = currentPages;
        this.isArchived = isArchived;
    }
    
    public MyBook(int isbn, int currentPages){
        this.isbn = isbn;
        this.currentPages = currentPages;
    }
    
    public MyBook(int isbn, boolean isArchived){
        this.isbn = isbn;
        this.isArchived = isArchived;
    }
    
    
    public int getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getYear() {
        return year;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public int getCurrentPages() {
        return currentPages;
    }

    public void setCurrentPages(int currentPages) {
        this.currentPages = currentPages;
    }

    public boolean isArchived() {
        return isArchived;
    }

    public void setArchived(boolean archived) {
        isArchived = archived;
    }

    public boolean isStatus() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
